<?php  

  # * 以下为必须参数演示
  # * 演示接口登录.
define('V', '1.0.5');
define('PHP_FILE', basename(__FILE__));
switch($_GET['act']){
    case 'index':
        //define('A_DRIVER','*a'); (连接类型, 可省略)
        //define('A_SERVER','127.0.0.1'); (服务主机,可省略)
        define('A_USERNAME','root');
        define('A_PASSWORD','root');
        //define('A_PERMANENT','*f[0/1]'); (是否长连接. 可省略)
        # 以下开启后为琐定某库访问.
        // define('A_DB','blog');
        // define('A_DB_LOCK', true);
        
        //define('A_CALLBACK',true);
        
        //define('A_DEBUG',1);
        define('A_URLQUERY','act=index&user=xxx');
        include './adminers.inc.php';
     break;
    case 'lockdb':
        define('A_USERNAME','root');
        define('A_PASSWORD','root');
        # 以下开启后为琐定某库访问.
        define('A_DB','mysql');
        define('A_DB_LOCK', true);
        
        include './adminers.inc.php';
     break;
    case 'callbaskdemo':
        define('A_USERNAME','root');
        define('A_PASSWORD','root');
        define('A_CALLBACK','get_userinfo');

        include './adminers.inc.php';
     break;
    case 'debug':
        define('A_USERNAME','root');
        define('A_PASSWORD','root');
        define('A_DEBUG', true);
        
        # adminers.inc.php已经有此函数了, 我们再定义一次. 让报错显示出来.
        // function fun_err(){}
        
        include './adminers.inc.php';
     break;
    case 'adata':
        define('A_USERNAME','root');
        define('A_PASSWORD','root');

        define('A_DATA','./Data/');
        include './adminers.inc.php';
        
     break;
    case 'allparem':
        define('A_DRIVER','mysql'); 
        define('A_SERVER','127.0.0.1');
        define('A_USERNAME','root');
        define('A_PASSWORD','root');
        define('A_PERMANENT','1');
        
        # 以下开启后为琐定某库访问.
        define('A_DB','mysql');
        define('A_DB_LOCK', true);
        
        define('A_CALLBACK','get_info');
        
        define('A_DEBUG',1);
        define('A_URLQUERY','act=allparem&sex=man&age=10'); // 设置默认参数,
        include './adminers.inc.php';
     break;
     case 'closeleft':
        define('A_USERNAME','root');
        define('A_PASSWORD','root');
        define('A_LEFTCLOSE', 1);
        //define('A_CALLBACK', 'get_userinfo');
        
        include './adminers.inc.php';
     break;
     case 'cssjs':
        define('A_USERNAME','root');
        define('A_PASSWORD','root');
        define('A_CSS', './demo.css');
        define('A_JS', './demo.js');
        
        include './adminers.inc.php';
     break;
}

if(defined('A_PASSWORD')){
    exit();
}

function tem_demo_url_str($caseact){
    return './'.PHP_FILE.'?act='.$caseact;
}

function get_info($info){
    print_r($info);
    return true; // false表示无法登录, close表示功能已经关闭.
    //return 'close';
}

function get_userinfo($info){
    
    print_r($info);
    return true; // false表示无法登录, close表示功能已经关闭.
    //return 'close';
}

?>

<!DOCTYPE HTML><html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="Yuan" />
	<title>Adminers <?php echo V;?> 演示</title>
<style type="text/css">
    body{
        font-size: 13px; 
        font-family: Verdana, Arial, Helvetica, "Trebuchet MS", Tahoma, Geneva, "Lucida Sans Unicode", "Lucida Grande", sans-serif;
        line-height: 20px;
        text-align: center;
    }
    h1{
        background: url("data:image/png;base64,/9j/4QDJRXhpZgAASUkqAAgAAAAHABIBAwABAAAAAQAAABoBBQABAAAAYgAAABsBBQABAAAAagAAACgBAwABAAAAAgAAADEBAgAVAAAAcgAAADIBAgAUAAAAhwAAAGmHBAABAAAAmwAAAAAACgBIAAAAAQAAAEgAAAABAAAAUGhvdG9GaWx0cmUgU3R1ZGlvIFgAMjAxMzowNjoxMyAxMTo1ODo1MQADAACQBwAEAAAAMDIxMAKgAwABAAAAGQAAAAOgAwABAAAAGAAAAP/bAEMAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/bAEMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/AABEIABgAGQMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP6dP2oP2gPjefjZ4i+FXgjxDeeFPB3g6y8PwXUvhmNIdd1e81LQdM1u+vNT1PZNqFrp9t/bEFlbRaebSzVYy9zPNcTFYsXwRo/iu4aLV38TeJX1JyrPfNrGpvOzn5smfz2JYnnlsZJ7Vzmq3XjCD/gpz8TW8Aar4a1TXYtA0Z7nwj42udQ0nSIbaT4a+DMzadrmkaZrF5ZtqUSbpRd6Nq2nfaIGDG1LS4/Lb4l/t0/ELwv/AMFBfFHwo0bUrbwD4n8CWMEerW1lrcfjTRrvxP4hsRf2OjaJYy2ekaQUsLO5sbrVtUv9GYwLLc2lskV1EkrfTcL8OZjxRiVl+WQoqrTwjxVSpXm6dOnSpqKcqnLGc3ecoQShCbc5xXLbVfnviHx/knhzk1XiDPljq2FWLpYWnh8vorEYutUrVIR5aVOdWhS/dxk6tTnrU4xpU51JTSi2f0b/AAR+K+qyfExPhFr/AIrk8R6tc+DNY8ZpY35S61nRrLRNV0DTPPuL9VWUWuoS64scVlqLTXIe3FzaskAlR/quvwi/Zn8c6x8Kf2nvBvxF+LniWXxNL8WLOX4UPqcb6LYweHdT+JvifQZ/CtzqJS3046nbv4m0fSvCFsLeIaky69FqVwlxFp924/djzT/zyl/75H/xVeZxXw9juHsZRwuLdGpGrTlVoYnDTlPD14c0YT9nKcac1KnUTjOE6cJrSXK4Tpyl3eHPiBkfiDk9bNcn+tUHhsT9UxuX4+nClj8DW5I1aUcRTpVa9Plr0KkK1GrSrVac4OUOdVadWlT/ADs+If7K/ik/tP6j8c9R0CH4qfDjxTp5mvfD2mXR0rx14P1caFpOiodLdNT0K61HSUj0i3uLG50TWrbWrNp7m3msbqALKf5ef2+v2MPG/wALv2xvHn7SX/CqvjzD8N/GtnaapZa7bQ+LbfUPCPiSysYdPnN1rmpWfiK3uxcz2VvqGnT+JprrSZobq+0ie5spo7OW5KK+k8O+IcfkHEOBng44epHH+zy/E0sTCpOnKhWqUm3FUqtGcatOdOE6VRTvGS1UouUX8x42cF5VxjwHnmHzGvmGElluHr5rhcTllejh8TDEYWlN+ylOvh8TTnhcTDmoYqhKm41qM5xvF2lHV/4Jo/DL9sj9uL9q74Q6p8UG8T+EP2bPgd468JfE/wAV6/4n0nUtLj+IWqfDbXLfxL4K8D+GIkintNWv7zxXY6Tda7f2uof2doWgwan512dRu9MsLv8AuF/0/wD5+f8AyF/9lRRUeJ+e47OeJKtPFKhTpZY54PC0sNS9lTjT56dSU5RlKd6tSUlzyTimoQSira9XglwhknCvA+AWU0akJZxClmePq1qiqVa2JnD2XxKMP3cIQSpxabjeXvO6t//Z") no-repeat scroll 2px center;
        padding-left: 36px;
        line-height: 40px;
    }
</style>
</head>
<body>
<div style="margin: 0 auto; width: 480px; padding: 18px; border: 3px solid silver; text-align: left;">
<h1>Adminers <?php echo V;?></h1>
    <ul style="list-style:decimal inside ;">
        <li><a target="_blank" href="<?php echo tem_demo_url_str('index');?>">普通接口登录</a></li>
        <li><a target="_blank" href="<?php echo tem_demo_url_str('closeleft');?>">默认关闭侧边栏</a></li>
        <li><a target="_blank" href="<?php echo tem_demo_url_str('lockdb');?>">琐定某个库访问</a></li>
        <li><a target="_blank" href="<?php echo tem_demo_url_str('callbaskdemo');?>">callback回调数据</a></li>
        <li><a target="_blank" href="<?php echo tem_demo_url_str('debug');?>">debug演示</a></li>
        <li><a target="_blank" href="<?php echo tem_demo_url_str('cssjs');?>">加载外部CSS, JS</a></li>
        <li><a target="_blank" href="<?php echo tem_demo_url_str('adata');?>">演示缓存目录</a></li>
        <li><a target="_blank" href="<?php echo tem_demo_url_str('allparem');?>">全部参数演示</a></li>
    </ul>
    <br />
    <br />
    <br />
    <div><a href="http://www.fenanr.com/">分享工作室</a> Adminers <?php echo V;?></div>
</div>
</body>
</html>